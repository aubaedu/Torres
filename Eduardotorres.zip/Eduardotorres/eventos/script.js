var nombre=document.getElementById('datoNombre');
var edad=document.getElementById('datoEdad');
var estatura=document.getElementById('datoEstatura');
var reg=document.getElementById('Reg');

var datos =[];

function guardarDatos(){

	datos.push(nombre.value + "<br>" + edad.value + "<br>" + estatura.value + "<br><hr>");
	var registro = datos.toString();
	reg.innerHTML=registro;
}