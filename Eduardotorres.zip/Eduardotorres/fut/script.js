
    function mostrarDatos(){
      let resumen = document.getElementById("resumen").value;
      let apaterno = document.getElementById("apaterno").value;
      let amaterno = document.getElementById("amaterno").value;
      let nombres = document.getElementById("nombres").value;
      let tipo_doc = document.getElementById("tipo_doc").value;
      let nro_doc = document.getElementById("nro_doc").value;
      let ruc = document.getElementById("ruc").value;
      let nombre_via = document.getElementById("nombre_via").value;
      let num_inmueble = document.getElementById("num_inmueble").value;
      let interior_piso = document.getElementById("interior_piso").value;
      let mz_lote_km = document.getElementById("mz_lote_km").value;
      let nombre_zona = document.getElementById("nombre_zona").value;
      let departamento = document.getElementById("departamento").value;
      let provincia = document.getElementById("provincia").value;
      let distrito = document.getElementById("distrito").value;
      let telefonos = document.getElementById("telefonos").value;
      let email = document.getElementById("email").value;
      let fundamentacion = document.getElementById("fundamentacion").value;
      let otros_docs = document.getElementById("otros_docs").value;
      let lugar = document.getElementById("lugar").value;
      let fecha = document.getElementById("fecha").value;

      // Documentos adjuntos
      let docs = [];
      if(document.getElementById("doc_dni").checked) docs.push("Copia de DNI");
      if(document.getElementById("doc_ruc").checked) docs.push("Copia de RUC");
      if(document.getElementById("doc_poder").checked) docs.push("Poder / Mandato");
      if(document.getElementById("doc_pruebas").checked) docs.push("Documentos probatorios");
      if(otros_docs) docs.push("Otros: " + otros_docs);

      let contenido = `
        <p><strong>Resumen:</strong> ${resumen}</p>
        <p><strong>Solicitante:</strong> ${apaterno} ${amaterno}, ${nombres}</p>
        <p><strong>Documento:</strong> ${tipo_doc} - ${nro_doc} | RUC: ${ruc}</p>
        <p><strong>Dirección:</strong> ${nombre_via}, N° ${num_inmueble}, Interior/Piso: ${interior_piso}, Mz/Lote/Km: ${mz_lote_km}, Zona: ${nombre_zona}, ${distrito}, ${provincia}, ${departamento}</p>
        <p><strong>Teléfono:</strong> ${telefonos} | <strong>Email:</strong> ${email}</p>
        <p><strong>Fundamentación:</strong> ${fundamentacion}</p>
        <p><strong>Documentos adjuntos:</strong> ${docs.join(", ") || "Ninguno"}</p>
        <p><strong>Lugar y fecha:</strong> ${lugar}, ${fecha}</p>
      `;

      document.getElementById("contenido").innerHTML = contenido;
    }
