function cambiarTema() {
    const body = document.body;
    if (body.classList.contains("tema-claro")) {
        body.classList.remove("tema-claro");
        body.classList.add("tema-oscuro");
    } else {
        body.classList.remove("tema-oscuro");
        body.classList.add("tema-claro");
    }
}

function marcarError() {
    const nombre = document.getElementById("nombre");
    const correo = document.getElementById("correo");

    if (nombre.value === "" || correo.value === "") {
        nombre.classList.add("error");
        correo.classList.add("error");
        alert("Por favor completa los campos obligatorios.");
    } else {
        nombre.classList.remove("error");
        correo.classList.remove("error");
        alert("Formulario enviado correctamente.");
    }
}
